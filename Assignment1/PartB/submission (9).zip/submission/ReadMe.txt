Q1.
Enter the number n when the prompt is "Enter n"
Enter the number r when the prompt is "Enter r"

Q2.
Iterative: Enter the number n when asked for input
Tail-recursive: Enter the number n when the prompt is "Input Number"
Recursive: Enter the number n when asked for input

Q3.
Input format is: <operator[mul/sum/sub/div]><single space><first_number><single space><second_number>