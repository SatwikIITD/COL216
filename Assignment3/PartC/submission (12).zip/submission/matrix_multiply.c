#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
void multiply(int n, double **A, double **B, double **C, char *order) {
    // if (strcmp(order, "ijk") == 0) {
    //     for (int i = 0; i < n; i++) {
    //         for (int j = 0; j < n; j++) {
    //             for (int k = 0; k < n; k++) {
    //                 C[i][j] += A[i][k] * B[k][j];
    //             }
    //         }
    //     }
    // } else if (strcmp(order, "ikj") == 0) {
    //     for (int i = 0; i < n; i++) {
    //         for (int k = 0; k < n; k++) {
    //             for (int j = 0; j < n; j++) {
    //                 C[i][j] += A[i][k] * B[k][j];
    //             }
    //         }
    //     }
    // } else if (strcmp(order, "jik") == 0) {
    //     for (int j = 0; j < n; j++) {
    //         for (int i = 0; i < n; i++) {
    //             for (int k = 0; k < n; k++) {
    //                 C[i][j] += A[i][k] * B[k][j];
    //             }
    //         }
    //     }
    // } else if (strcmp(order, "jki") == 0) {
    //     for (int j = 0; j < n; j++) {
    //         for (int k = 0; k < n; k++) {
    //             for (int i = 0; i < n; i++) {
    //                 C[i][j] += A[i][k] * B[k][j];
    //             }
    //         }
    //     }
    // } else if (strcmp(order, "kij") == 0) {
    //     for (int k = 0; k < n; k++) {
    //         for (int i = 0; i < n; i++) {
    //             for (int j = 0; j < n; j++) {
    //                 C[i][j] += A[i][k] * B[k][j];
    //             }
    //         }
    //     }
    // } else if (strcmp(order, "kji") == 0) {
    //     for (int k = 0; k < n; k++) {
    //         for (int j = 0; j < n; j++) {
    //             for (int i = 0; i < n; i++) {
    //                 C[i][j] += A[i][k] * B[k][j];
    //             }
    //         }
    //     }
    // }
    if (strcmp(order, "kij") == 0) {
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }
    }
}

double **allocate_matrix(int n) {
    double **matrix = malloc(n * sizeof(double *));
    for (int i = 0; i < n; i++) {
        matrix[i] = malloc(n * sizeof(double));
    }
    return matrix;
}

void free_matrix(int n, double **matrix) {
    for (int i = 0; i < n; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

void fill_matrix(int n, double **matrix) {
    srand(time(NULL));  // Seed the random number generator
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = rand() / (double)RAND_MAX * 100;
        }
    }
}

int main() {
    struct timespec start, end;
    FILE *fp = fopen("matrix_multiplication_results.csv", "w");
    fprintf(fp, "Size,Order,Time\n");

    char *orders[] = {"ijk", "ikj", "jik", "jki", "kij", "kji"};
    int num_orders = 6;

    for (int n = 1; n <= 300; n++) {
        double **A = allocate_matrix(n);
        double **B = allocate_matrix(n);
        double **C = allocate_matrix(n);

        fill_matrix(n, A);
        fill_matrix(n, B);

        for (int order = 0; order < num_orders; order++) {
            // Reset C to zero before each multiplication
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    C[i][j] = 0;
                }
            }

            clock_gettime(CLOCK_MONOTONIC, &start);
            multiply(n, A, B, C, orders[order]);
            clock_gettime(CLOCK_MONOTONIC, &end);
            double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
            fprintf(fp, "%d,%s,%f\n", n, orders[order], elapsed_time);
        }

        free_matrix(n, A);
        free_matrix(n, B);
        free_matrix(n, C);
    }

    fclose(fp);
    return 0;
}
