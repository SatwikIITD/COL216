#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void transpose_new_matrix_ij(int n, double **A, double **B) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            B[j][i] = A[i][j];
        }
    }
}

void transpose_new_matrix_ji(int n, double **A, double **B) {
    for (int j = 0; j < n; j++) {
        for (int i = 0; i < n; i++) {
            B[j][i] = A[i][j];
        }
    }
}

void transpose_in_place_ij(int n, double **A) {
    double temp;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            temp = A[i][j];
            A[i][j] = A[j][i];
            A[j][i] = temp;
        }
    }
}

void transpose_in_place_ji(int n, double **A) {
    double temp;
    for (int j = 0; j < n; j++) {
        for (int i = j + 1; i < n; i++) {
            temp = A[i][j];
            A[i][j] = A[j][i];
            A[j][i] = temp;
        }
    }
}

double **allocate_matrix(int n) {
    double **matrix = malloc(n * sizeof(double *));
    for (int i = 0; i < n; i++) {
        matrix[i] = malloc(n * sizeof(double));
        for (int j = 0; j < n; j++) {
            matrix[i][j] = rand() / (double)RAND_MAX * 100;
        }
    }
    return matrix;
}

void free_matrix(int n, double **matrix) {
    for (int i = 0; i < n; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

void measure_transpose(int n, FILE *fp, int in_place, int order) {
    struct timespec start, end;
    double **A = allocate_matrix(n);
    double **B = allocate_matrix(n);

    clock_gettime(CLOCK_MONOTONIC, &start);
    if (in_place) {
        if (order == 0) { // ij order
            transpose_in_place_ij(n, A);
        } else { // ji order
            transpose_in_place_ji(n, A);
        }
    } else {
        if (order == 0) { // ij order
            transpose_new_matrix_ij(n, A, B);
        } else { // ji order
            transpose_new_matrix_ji(n, A, B);
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &end);

    double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
    fprintf(fp, "%d,%s,%s,%f\n", n, in_place ? "In-Place" : "New Matrix", order == 0 ? "IJ" : "JI", elapsed_time);

    free_matrix(n, A);
    if (!in_place) {
        free_matrix(n, B);
    }
}

int main() {
    int sizes[] = {100, 200, 300, 400, 500};
    int num_sizes = sizeof(sizes) / sizeof(sizes[0]);

    FILE *fp = fopen("transpose_timing_results.csv", "w");
    fprintf(fp, "Size,Method,Order,Time\n");

    for (int i = 0; i < num_sizes; i++) {
        int size = sizes[i];
        measure_transpose(size, fp, 1, 0);  // In-place transpose, ij
        measure_transpose(size, fp, 1, 1);  // In-place transpose, ji
        measure_transpose(size, fp, 0, 0);  // New matrix transpose, ij
        measure_transpose(size, fp, 0, 1);  // New matrix transpose, ji
    }

    fclose(fp);
    return 0;
}
