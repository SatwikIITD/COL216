import matplotlib.pyplot as plt
import pandas as pd

def plot_transpose_results(filename):
    # Read the CSV file into a DataFrame
    data = pd.read_csv(filename)

    # Filter data for in-place and new matrix methods
    in_place_data = data[data['Method'] == 'In-Place']
    new_matrix_data = data[data['Method'] == 'New Matrix']

    # Plotting in-place transpose results
    plt.figure(figsize=(10, 6))
    for order in ['IJ', 'JI']:
        subset = in_place_data[in_place_data['Order'] == order]
        plt.plot(subset['Size'], subset['Time'], label=f'In-Place {order}')
    for order in ['IJ', 'JI']:
        subset = new_matrix_data[new_matrix_data['Order'] == order]
        plt.plot(subset['Size'], subset['Time'], label=f'New Matrix {order}')
    
    plt.title('In-Place Matrix Transpose Performance')
    plt.xlabel('Matrix Size')
    plt.ylabel('Time (seconds)')
    plt.legend()
    plt.grid(True)
    plt.savefig('in_place_transpose_performance.png')
    plt.show()

    # # Plotting new matrix transpose results
    # plt.figure(figsize=(10, 6))
    
    # plt.title('New Matrix Transpose Performance')
    # plt.xlabel('Matrix Size')
    # plt.ylabel('Time (seconds)')
    # plt.legend()
    # plt.grid(True)
    # plt.savefig('new_matrix_transpose_performance.png')
    # plt.show()

# Run the plotting function
plot_transpose_results('transpose_timing_results.csv')
