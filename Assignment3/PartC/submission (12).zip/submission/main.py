import pandas as pd
import matplotlib.pyplot as plt

# Load the data
data = pd.read_csv('matrix_multiplication_results.csv')

# Plotting the execution time data
plt.figure(figsize=(14, 8))
for label, df in data.groupby('Order'):
    plt.plot(df['Size'], df['Time'], label=f'{label} Order', marker='o')
plt.xlabel('Matrix Size (n)')
plt.ylabel('Execution Time (seconds)')
plt.title('Matrix Multiplication Execution Time by Matrix Size and Loop Order')
plt.legend()
plt.grid(True)

# Save the plot to a PNG file with high resolution
plt.savefig('matrix_multiplication_times_linear.png', dpi=300)

# Show the plot
plt.show()
