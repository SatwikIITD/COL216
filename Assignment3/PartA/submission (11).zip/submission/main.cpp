#include <iostream>
#include <vector>
#include <set>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#define ll long long
using namespace std;

struct CacheLine{
    ll tag;
    bool valid;
    bool dirty;
    int time;
    CacheLine(): tag(0), valid(false), dirty(false), time(0){}
};

class Cache{

    public:
        int noSets;
        int assoc;
        int blockSize;
        string writePolicy;
        string writeAllocatePolicy;
        string evictionPolicy;
        vector<vector<CacheLine>> sets;
        int currentTime;
        //vector<set<pair<int,int>> s;
        int totalLoads;
        int totalStores;
        int loadHits;
        int loadMisses;
        int storeHits;
        int storeMisses;
        int totalCycles;
        // vector<int> mi;
        // vector<int> mi_index;
        void addressToIndexTag(ll address, int& setIndex, ll& tag){
            int offsetBits=log2(blockSize);
            int setBits=log2(noSets);
            setIndex=(address>>offsetBits) & ((1<<setBits)-1);
            tag=address>>(offsetBits+setBits);
        }

        int findEvictIndex(int setIndex){
            int indexToEvict=0;
            for(int i=0;i<assoc;i++){     
                if(sets[setIndex][i].time<sets[setIndex][indexToEvict].time){
                    indexToEvict=i;
                }
            }
            return indexToEvict; 
        }
    
        Cache(int noSets, int assoc, int blockSize, string writePolicy,string writeAllocatePolicy, string evictionPolicy):noSets(noSets),assoc(assoc),blockSize(blockSize),writePolicy(writePolicy),writeAllocatePolicy(writeAllocatePolicy), evictionPolicy(evictionPolicy),currentTime(1),totalLoads(0),totalStores(0),loadHits(0),loadMisses(0),storeHits(0),storeMisses(0),totalCycles(0){
            sets.resize(noSets,vector<CacheLine>(assoc));
        }

        void access(char type, ll address){
            int setIndex;
            ll tag;
            addressToIndexTag(address,setIndex,tag);
            bool hit=false;
            for(auto& line:sets[setIndex]){
                if(line.valid && line.tag==tag){
                    hit=true;
                    if (evictionPolicy == "lru") {
                        line.time = currentTime;
                    }
                    if(type=='s' && writePolicy=="write-back"){
                        line.dirty=true;
                    }
                    break;
                }
            }
            if(type=='l'){
                totalLoads++;
                if(hit){
                    loadHits++;
                }
                else{
                    loadMisses++;
                }
            }
            else{
                totalStores++;
                if(hit){
                    storeHits++;
                }
                else{
                    storeMisses++;
                }
            }

            if(type=='l'){
                if(hit){
                    totalCycles++;
                }
                else{   
                    totalCycles++;
                    totalCycles+=25*blockSize; //get the block from memory
                    int evictIndex=findEvictIndex(setIndex);
                    CacheLine& evict=sets[setIndex][evictIndex];
                    if(evict.valid && evict.dirty && writePolicy=="write-back"){
                        totalCycles+=25*blockSize; //send the whole block to memory
                    }
                    evict.tag=tag;
                    evict.valid=true;   
                    evict.dirty=false; 
                    evict.time=currentTime; // lru/fifo 
                }   
            }   
            else{
                if(hit){
                    totalCycles++;
                    if(writePolicy=="write-through"){
                        totalCycles+=100;
                        //totalCycles+=25*blockSize;
                    }
                }
                else{
                    if(writePolicy=="write-back"){
                        if(writeAllocatePolicy=="write-allocate"){
                            totalCycles+=25*blockSize;
                            totalCycles++;
                            int evictIndex=findEvictIndex(setIndex);
                            CacheLine& evict=sets[setIndex][evictIndex];
                            if(evict.valid && evict.dirty){
                                totalCycles+=25*blockSize; //write the block into memory
                            }
                            evict.tag=tag;
                            evict.valid=true;   
                            evict.dirty=true; 
                            evict.time=currentTime; // lru/fifo 
                        }
                        else{
                            totalCycles+=100;
                        }
                    }
                    else{
                        if(writeAllocatePolicy=="write-allocate"){
                            //totalCycles+=200;  
                            totalCycles+=25*blockSize; //bring the data from memory
                            totalCycles++;
                            //totalCycles+=25*blockSize;
                            totalCycles+=100; //write the data into memory
                            int evictIndex=findEvictIndex(setIndex);
                            CacheLine& evict=sets[setIndex][evictIndex];
                            evict.tag=tag;
                            evict.valid=true;   
                            evict.dirty=false; 
                            evict.time=currentTime;
                        }
                        else{
                            totalCycles+=100; // write the data into memory
                        }
                    }
                }
            }
            currentTime++;
        }

        void printStatistics(){
            cout<<"Total loads: "<<totalLoads<<endl;
            cout<<"Total stores: "<<totalStores<<endl;
            cout<<"Load hits: "<<loadHits<<endl;
            cout<<"Load misses: "<<loadMisses<<endl;
            cout<<"Store hits: "<<storeHits<<endl;
            cout<<"Store misses: "<<storeMisses<<endl;
            cout<<"Total cycles: "<<totalCycles<<endl;
            //cout<<"Hit rates: "<<((loadHits+storeHits)*(100.0)/(totalLoads+totalStores))<<endl; 
        }
};

int main(int argc, char *argv[]) {
    if (argc != 7) {
        std::cerr << " Error in input format " << std::endl;
        return 1;
    }

    int noSets = std::stoi(argv[1]);
    int assoc = std::stoi(argv[2]);
    int blockSize = std::stoi(argv[3]);
    std::string writePolicy = argv[5];
    std::string evictionPolicy = argv[6];
    std::string writeAllocationPolicy = argv[4];  

    Cache cache(noSets, assoc, blockSize, writePolicy, writeAllocationPolicy, evictionPolicy);

    char type;
    unsigned long address;
    string unused;  
   
    while (cin >> type >> std::hex >> address >> unused) {
        cache.access(type, address);
    }
    //after all the access, write the remaining dirty bits into memory
    if(writePolicy=="write-back"){
        for(auto& set:cache.sets){
            for(auto& line:set){
                if(line.dirty && line.valid){
                    cache.totalCycles+=100;
                }
            }
        }
    }
    cache.printStatistics();
}