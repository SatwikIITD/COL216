# COL 216 Assignment 3: Cache Simulator

## Author Information

- **Name:** SATWIK
- **Student ID:** 2022CS51150

## Introduction

This project involves creating a cache simulator with various configurations to study different cache behaviors. This simulator supports multiple write policies (write-through and write-back), write allocation policies (write-allocate and no-write-allocate), and eviction policies (LRU and FIFO).

## Purpose

The purpose of this assignment is to design and implement a cache simulator that accurately models the performance of a cache given different configurations and policies. By varying the input parameters and using traces from real processors, the simulator provides insights into how different settings impact the performance of a cache system.

## Simulation Setup and Results

### Write Policies

The simulator examines two main write policies:

- **Write-through:** Offers better throughput (fewer cycles) and a higher hit rate compared to write-back under the same cache specifications.
- **Write-back:** Generally sees a lower performance compared to write-through in our tests.

#### Observations:

- The write-through policy, especially when combined with the write-allocate policy, shows improved performance over no-write-allocate setups.

### Cache Configuration Variability

- **Associativity:** Increasing the cache's associativity generally reduces the miss rate and lowers the number of cycles required.
- **Block Size:** Larger block sizes tend to increase the number of cycles; however, they also improve the hit rate compared to smaller block sizes.

### Eviction Policies

- **LRU Eviction:** Demonstrates fewer cycles and a better hit rate, making it more effective compared to FIFO.
- **FIFO Eviction:** Compared in this study but found less optimal than LRU.

## Graphical Analysis

### Associativity vs. Performance

![Associativity vs. Performance Graph](Associativity_Analysis_Comparison.png)

### Block Size vs. Performance

![Block Size vs. Performance Graph](Block_Size_Analysis_Comparison.png)

### Example System Image

![System Image](lruvfifo.png)

## Conclusion


### How to View the Images

Replace `path/to/graph.png`, `path/to/associativity_graph.png`, and `path/to/system_image.png` with the actual paths to your images. These can be URLs or relative paths depending on where you host the README.md and related images.
